# B站视频实时在线人数排行榜

一个用于获取B站热门视频实时在线观看人数并生成排行榜的Python爬虫项目，包含数据采集和可视化展示功能。

## 功能特点

- 自动获取B站热门视频列表
- 实时获取视频在线观看人数
- 获取视频封面、标题、UP主等信息
- 数据保存为JSON格式
- 美观的Web界面展示
  - 支持按在线人数/标题/UP主排序
  - 支持视频标题和UP主搜索
  - 响应式布局，适配移动端
  - 视频封面懒加载

## 安装依赖

```bash
pip install requests beautifulsoup4
```

## 使用方法

1. 获取视频数据：
```bash
python video_ranking.py
```
程序会：
- 获取B站热门视频列表
- 获取每个视频的实时在线人数
- 获取视频封面等信息
- 保存结果到 bilibili_online_ranking.json

2. 查看可视化界面：
```bash
python -m http.server 8000
```
然后在浏览器中访问 http://localhost:8000 即可查看排行榜。

## 数据格式

生成的JSON数据格式如下：
```json
{
  "BV号": {
    "title": "视频标题",
    "owner": "UP主名称",
    "online_count": "在线人数",
    "count_num": 数值化的在线人数,
    "pic": "视频封面URL"
  }
}
```

## 版本历史

v1.1.0 (2024-03-xx)
- 添加Web可视化界面
- 支持多种排序方式
- 支持搜索功能
- 优化图片加载
- 修复HTTP图片链接问题

v1.0.0 (2024-03-xx)
- 实现基础功能
- 支持热门视频获取
- 添加在线人数排序
- 支持JSON格式保存

## License

MIT License